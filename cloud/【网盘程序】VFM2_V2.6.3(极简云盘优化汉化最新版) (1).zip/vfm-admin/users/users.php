<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$8D6eAKyK$1ZK.LhO3vo08JzgpSBGXV0',
    'role' => 'superadmin',
  ),
);
